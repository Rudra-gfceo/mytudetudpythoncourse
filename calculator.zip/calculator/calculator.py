import tkinter as tk
from tkinter import messagebox, ttk
import random
import math


class EasterEggCalculator:
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("🥚 Easter Egg Calculator Pro 🥚")
        self.window.geometry("450x700")

        # Modern color scheme
        self.colors = {
            'bg_main': '#1e1e2e',
            'bg_secondary': '#313244',
            'bg_display': '#45475a',
            'accent': '#89b4fa',
            'accent_hover': '#74c7ec',
            'number': '#a6e3a1',
            'number_hover': '#94e2d5',
            'operator': '#f38ba8',
            'operator_hover': '#eba0ac',
            'special': '#fab387',
            'special_hover': '#f9e2af',
            'text_primary': '#cdd6f4',
            'text_secondary': '#11111b'
        }

        self.window.configure(bg=self.colors['bg_main'])
        self.window.resizable(False, False)

        # Set window icon (if available)
        try:
            self.window.iconbitmap("calculator.ico")
        except:
            pass

        # Easter egg counters
        self.easter_egg_count = 0
        self.konami_sequence = []
        self.konami_code = ['Up', 'Up', 'Down', 'Down', 'Left', 'Right', 'Left', 'Right']

        # Current calculation
        self.current = ""
        self.total = 0

        # Configure custom styles
        self.setup_styles()
        self.create_display()
        self.create_buttons()
        self.bind_keys()

    def setup_styles(self):
        """Configure ttk styles for modern look"""
        self.style = ttk.Style()
        self.style.theme_use('clam')

        # Configure button style
        self.style.configure('Modern.TButton',
                             font=('Segoe UI', 12, 'bold'),
                             focuscolor='none',
                             borderwidth=0,
                             relief='flat')

        # Configure entry style
        self.style.configure('Display.TEntry',
                             font=('JetBrains Mono', 24, 'bold'),
                             fieldbackground=self.colors['bg_display'],
                             foreground=self.colors['text_primary'],
                             borderwidth=0,
                             insertcolor=self.colors['accent'])

    def create_display(self):
        # Header frame with gradient effect
        header_frame = tk.Frame(self.window, bg=self.colors['bg_main'], height=120)
        header_frame.pack(fill='x', padx=20, pady=(20, 10))
        header_frame.pack_propagate(False)

        # Title with modern typography
        title_label = tk.Label(header_frame,
                               text="🐍 PyCalc Pro",
                               font=('Segoe UI', 20, 'bold'),
                               fg=self.colors['accent'],
                               bg=self.colors['bg_main'])
        title_label.pack(pady=(10, 5))

        subtitle_label = tk.Label(header_frame,
                                  text="Advanced Calculator with Easter Eggs",
                                  font=('Segoe UI', 10),
                                  fg=self.colors['text_primary'],
                                  bg=self.colors['bg_main'])
        subtitle_label.pack()

        # Display container with rounded corners effect
        display_container = tk.Frame(self.window, bg=self.colors['bg_secondary'],
                                     relief='flat', bd=0)
        display_container.pack(padx=25, pady=15, fill='x', ipady=15)

        # Secondary display for operations
        self.operation_display = tk.Label(display_container,
                                          text="",
                                          font=('JetBrains Mono', 12),
                                          fg=self.colors['text_primary'],
                                          bg=self.colors['bg_secondary'],
                                          anchor='e')
        self.operation_display.pack(fill='x', padx=15, pady=(5, 0))

        # Main display
        self.display = tk.Entry(display_container,
                                font=('JetBrains Mono', 28, 'bold'),
                                justify='right',
                                bd=0,
                                bg=self.colors['bg_secondary'],
                                fg=self.colors['text_primary'],
                                insertbackground=self.colors['accent'],
                                state='readonly',
                                relief='flat')
        self.display.pack(fill='x', padx=15, pady=(5, 10), ipady=8)

    def create_buttons(self):
        # Main button container
        button_container = tk.Frame(self.window, bg=self.colors['bg_main'])
        button_container.pack(padx=25, pady=10, fill='both', expand=True)

        # Button layout with modern design
        buttons = [
            [('C', 'special'), ('⌫', 'special'), ('🎲', 'special'), ('÷', 'operator')],
            [('7', 'number'), ('8', 'number'), ('9', 'number'), ('×', 'operator')],
            [('4', 'number'), ('5', 'number'), ('6', 'number'), ('−', 'operator')],
            [('1', 'number'), ('2', 'number'), ('3', 'number'), ('+', 'operator')],
            [('🥚', 'special'), ('0', 'number'), ('.', 'number'), ('=', 'operator')]
        ]

        for row_idx, row in enumerate(buttons):
            button_row = tk.Frame(button_container, bg=self.colors['bg_main'])
            button_row.pack(fill='x', pady=4)

            for col_idx, (btn_text, btn_type) in enumerate(row):
                btn = self.create_modern_button(button_row, btn_text, btn_type)
                btn.pack(side='left', padx=4, fill='both', expand=True)

        # Status bar
        self.create_status_bar()

    def create_modern_button(self, parent, text, btn_type):
        """Create a modern styled button"""
        # Color mapping
        type_colors = {
            'number': (self.colors['number'], self.colors['number_hover']),
            'operator': (self.colors['operator'], self.colors['operator_hover']),
            'special': (self.colors['special'], self.colors['special_hover'])
        }

        bg_color, hover_color = type_colors[btn_type]

        btn = tk.Button(parent,
                        text=text,
                        font=('Segoe UI', 14, 'bold'),
                        bg=bg_color,
                        fg=self.colors['text_secondary'],
                        activebackground=hover_color,
                        activeforeground=self.colors['text_secondary'],
                        relief='flat',
                        bd=0,
                        cursor='hand2',
                        command=lambda: self.button_click(text))

        # Hover effects
        btn.bind('<Enter>', lambda e: btn.configure(bg=hover_color))
        btn.bind('<Leave>', lambda e: btn.configure(bg=bg_color))

        # Button sizing
        btn.configure(height=2, width=6)

        return btn

    def create_status_bar(self):
        """Create a status bar at the bottom"""
        status_frame = tk.Frame(self.window, bg=self.colors['bg_secondary'], height=40)
        status_frame.pack(fill='x', side='bottom')
        status_frame.pack_propagate(False)

        self.status_text = tk.Label(status_frame,
                                    text=f"🥚 Eggs found: {self.easter_egg_count} | Ready to calculate!",
                                    font=('Segoe UI', 9),
                                    fg=self.colors['text_primary'],
                                    bg=self.colors['bg_secondary'])
        self.status_text.pack(pady=10)

    def update_status(self, message):
        """Update status bar message"""
        self.status_text.configure(text=message)

    def bind_keys(self):
        """Bind keyboard events"""
        self.window.bind('<Key>', self.key_press)
        self.window.focus_set()

    def key_press(self, event):
        """Handle keyboard input and Easter egg sequences"""
        key = event.keysym

        # Track Konami code
        if key in ['Up', 'Down', 'Left', 'Right']:
            self.konami_sequence.append(key)
            if len(self.konami_sequence) > len(self.konami_code):
                self.konami_sequence.pop(0)

            if self.konami_sequence == self.konami_code:
                self.activate_konami_code()

        # Regular key handling
        if key.isdigit() or key == 'period':
            if key == 'period':
                key = '.'
            self.button_click(key)
        elif key in ['plus', 'minus', 'asterisk', 'slash']:
            operators = {'plus': '+', 'minus': '−', 'asterisk': '×', 'slash': '÷'}
            self.button_click(operators[key])
        elif key == 'Return':
            self.button_click('=')
        elif key in ['Escape', 'Delete']:
            self.button_click('C')
        elif key == 'BackSpace':
            self.button_click('⌫')

    def button_click(self, value):
        """Handle button clicks with animations"""
        # Add subtle button feedback
        self.window.update()

        current_display = self.display.get()

        if value == '🥚':
            self.easter_egg_surprise()
        elif value == '🎲':
            self.random_number_generator()
        elif value == 'C':
            self.clear_display()
        elif value == '⌫':
            self.backspace()
        elif value == '=':
            self.calculate()
        elif value in '÷×−+':
            self.add_operator(value)
        else:
            self.add_number(value)

        # Update status
        self.update_status(f"🥚 Eggs found: {self.easter_egg_count} | Last: {value}")

    def add_number(self, number):
        """Add number to display with better formatting"""
        current = self.display.get()
        if current == "0" and number != ".":
            new_display = number
        elif current == "Error":
            new_display = number
        else:
            new_display = current + str(number)

        self.update_display(new_display)

    def add_operator(self, operator):
        """Add operator to display"""
        current = self.display.get()
        if current and current != "Error" and current[-1] not in '÷×−+':
            self.update_display(current + operator)
            self.operation_display.configure(text=current + operator)

    def backspace(self):
        """Remove last character"""
        current = self.display.get()
        if current and current != "Error":
            new_display = current[:-1] if len(current) > 1 else "0"
            self.update_display(new_display)

    def calculate(self):
        """Perform calculation with enhanced error handling"""
        try:
            expression = self.display.get()
            if not expression or expression == "Error":
                return

            # Store for history
            original_expression = expression

            # Replace symbols with Python operators
            expression = expression.replace('÷', '/').replace('×', '*').replace('−', '-')

            result = eval(expression)

            # Format result nicely
            if isinstance(result, float):
                if result.is_integer():
                    result = int(result)
                else:
                    result = round(result, 10)  # Avoid floating point errors

            # Easter egg for special results
            self.check_special_results(result)

            self.update_display(str(result))
            self.operation_display.configure(text=f"{original_expression} = {result}")

        except ZeroDivisionError:
            self.update_display("Error")
            self.show_easter_egg_message("🤖 Cannot divide by zero!\nEven computers have limits! 🤖")
        except:
            self.update_display("Error")
            messagebox.showerror("Calculation Error", "🤖 Beep boop! Math broke! 🤖\nPlease check your expression.")

    def check_special_results(self, result):
        """Check for special Easter egg results"""
        if result == 42:
            self.show_easter_egg_message("🌌 The Answer to Life, Universe & Everything! 🌌")
        elif result == 69:
            self.show_easter_egg_message("😏 Nice! 😏")
        elif result == 404:
            self.show_easter_egg_message("🔍 Error 404: Result not found! 🔍")
        elif result == 1337:
            self.show_easter_egg_message("😎 L33T H4X0R! 😎")
        elif abs(result - math.pi) < 0.01:
            self.show_easter_egg_message("🥧 Mmm... Pi! Approximately 3.14159... 🥧")
        elif abs(result - math.e) < 0.01:
            self.show_easter_egg_message("📊 Euler's number! The base of natural logarithm! 📊")
        elif result == 0:
            messages = ["🕳️ The void stares back... 🕳️", "🌌 Nothing... but also everything! 🌌"]
            self.show_easter_egg_message(random.choice(messages))

    def clear_display(self):
        """Clear the display with animation"""
        self.update_display("0")
        self.operation_display.configure(text="")

    def update_display(self, value):
        """Update display with new value"""
        self.display.configure(state='normal')
        self.display.delete(0, tk.END)
        self.display.insert(0, value)
        self.display.configure(state='readonly')

    def easter_egg_surprise(self):
        """Enhanced Easter egg function"""
        self.easter_egg_count += 1

        surprises = [
            "🥚 You found an egg! 🥚",
            "🐣 *Crack* Something's hatching! 🐣",
            "🐰 The Easter Bunny approves! 🐰",
            "🌟 You're egg-cellent at clicking! 🌟",
            "🎉 Surprise! This calculator has secrets! 🎉",
            "🤓 Fun fact: There are 10 types of people in the world...",
            "☕ Time for a coffee break? ☕",
            "🎯 Achievement: Persistent Clicker! 🎯",
            f"🔢 Easter egg #{self.easter_egg_count} discovered! 🔢",
            "🚀 Houston, we have an Easter egg! 🚀"
        ]

        # Special milestones
        if self.easter_egg_count == 5:
            surprises.append("🏅 5 eggs found! You're getting good at this! 🏅")
        elif self.easter_egg_count == 10:
            surprises.append("🏆 Achievement Unlocked: Egg Hunter! 🏆")
        elif self.easter_egg_count == 25:
            surprises.append("🎊 Wow! 25 eggs! You're dedicated! 🎊")

        message = random.choice(surprises)
        self.show_easter_egg_message(message)

        # Special action every 3rd click
        if self.easter_egg_count % 3 == 0:
            self.rainbow_mode()

        # Update status
        self.update_status(f"🥚 Eggs found: {self.easter_egg_count} | {message.split('!')[0]}!")

    def random_number_generator(self):
        """Enhanced random number generator"""
        categories = [
            (1, 10, "🎲 Small dice roll"),
            (1, 100, "🎯 Random percentage"),
            (1, 1000, "🎰 Lucky number"),
            (2000, 2030, "📅 Random year"),
            (1, 6, "🎲 Classic dice")
        ]

        min_val, max_val, category = random.choice(categories)
        random_num = random.randint(min_val, max_val)

        self.update_display(str(random_num))

        fun_messages = [
            f"{category}: {random_num}! 🎊",
            f"🔮 The crystal ball shows... {random_num}! ✨",
            f"🎰 Jackpot! You rolled {random_num}! 🎰",
            f"🌟 Your lucky number today: {random_num}! 🌟"
        ]

        messagebox.showinfo("🎲 Random Magic!", random.choice(fun_messages))
        self.update_status(f"🎲 Generated random number: {random_num}")

    def show_easter_egg_message(self, message):
        """Enhanced Easter egg message display"""
        messagebox.showinfo("🎊 Easter Egg Discovery! 🎊", message)

    def rainbow_mode(self):
        """Enhanced rainbow color mode"""
        original_bg = self.window.cget('bg')
        colors = ['#ff6b6b', '#feca57', '#48dbfb', '#ff9ff3', '#54a0ff', '#5f27cd']

        def change_color(index=0):
            if index < 12:  # Flash 12 times
                color = colors[index % len(colors)]
                self.window.configure(bg=color)
                self.window.after(150, lambda: change_color(index + 1))
            else:
                self.window.configure(bg=original_bg)

        change_color()
        self.show_easter_egg_message("🌈 RAINBOW MODE ACTIVATED! 🌈\n\nTaste the rainbow of mathematics! 🎨")

    def activate_konami_code(self):
        """Enhanced Konami code Easter egg"""
        self.konami_sequence = []  # Reset sequence

        original_title = self.window.title()
        self.window.title("🚀 ↑↑↓↓←→←→ SUPER CALCULATOR ACTIVATED! 🚀")

        messagebox.showinfo("🎮 KONAMI CODE ACTIVATED! 🎮",
                            "🚀 CHEAT CODE SUCCESSFUL! 🚀\n\n"
                            "✨ Special powers unlocked:\n"
                            "• Infinite calculations! ∞\n"
                            "• Enhanced precision! 📐\n"
                            "• Secret developer mode! 👨‍💻\n\n"
                            "Just kidding... or am I? 😏")

        # Temporary super mode visual
        self.window.configure(bg='#8b5cf6')
        self.window.after(5000, lambda: self.window.configure(bg=self.colors['bg_main']))
        self.window.after(5000, lambda: self.window.title(original_title))

        # Update status
        self.update_status("🚀 KONAMI CODE ACTIVATED! Secret mode enabled!")

    def run(self):
        """Start the calculator with welcome message"""
        # Enhanced welcome message
        welcome_msg = """🎉 Welcome to Easter Egg Calculator Pro! 🎉

🔍 Hidden features to discover:
• Click the 🥚 for surprises & achievements
• Try the 🎲 for random number magic
• Calculate special numbers (42, π, etc.)
• Use Konami Code: ↑↑↓↓←→←→
• Full keyboard support included!

🎯 Pro tip: Every feature has Easter eggs!
Happy calculating! 🧮✨"""

        messagebox.showinfo("🚀 Welcome to PyCalc Pro! 🚀", welcome_msg)

        self.update_display("0")
        self.window.mainloop()


if __name__ == "__main__":
    calculator = EasterEggCalculator()
    calculator.run()